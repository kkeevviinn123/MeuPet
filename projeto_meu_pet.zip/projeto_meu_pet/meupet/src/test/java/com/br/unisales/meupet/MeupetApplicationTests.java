package com.br.unisales.meupet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MeupetApplicationTests {

	@Test
	void contextLoads() {
	}

}
